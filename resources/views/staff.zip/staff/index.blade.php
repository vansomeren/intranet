@include('layouts.header')
<div class="mainwrapper">
    @include('layouts.sidebar')
    <div class="mainpanel">
        <div class="pageheader">
            <div class="media">
                <div class="pageicon pull-left">
                    <i class="fa fa-th-list"></i>
                </div>
                <div class="media-body">
                    <ul class="breadcrumb">
                        <li><a href=""><i class="glyphicon glyphicon-home"></i></a></li>
                        <li><a href="">Employees</a></li>
                        <li>View Employees</li>
                    </ul>
                    <h4>View Employees</h4>
                </div>
            </div><!-- media -->
        </div><!-- pageheader -->
        {!! Form::open() !!}
        <div class="contentpanel">
            <div class="pull-right" style="margin:10px;">

                <a class="btn btn-success" href="{{ route('employee.create') }}"> Create New Employee</a>


            </div>
            <div class="row">
                <div class="col-md-16">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Employee Number</th>
                                <th>Full Name</th>
                                <th>Email Address</th>
                                <th>Branch</th>
                                <th>Department</th>
                                <th>Designation</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($employees as $employee)
                                <tr>
                                    <td>{{$employee->employee_id}}</td>
                                    <td>{{$employee->fullname}}</td>
                                    <td>{{$employee->email}}</td>
                                    <td>{{$employee->branch->name}}</td>
                                    <td>{{$employee->department->name}}</td>
                                    <td>{{$employee->designation->name}}</td>
                                    <td>

                                        <a class="btn btn-info" href="{{ route('employee.show',$employee->id) }}">Show</a>


                                        <a class="btn btn-primary" href="{{ route('employee.edit',$employee->id) }}">Edit</a>



                                        {!! Form::open(['method' => 'DELETE','route' => ['employee.destroy',$employee->id],'style'=>'display:inline']) !!}

                                        {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}

                                        {!! Form::close() !!}


                                    </td>

                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div><!-- table-responsive -->
                </div>
            </div>

        </div>
        {!! Form::close() !!}
    </div>

</div>

@include('layouts.footer')
<script>
    jQuery(document).ready(function(){

        // Delete row in a table
        jQuery('.delete-row').click(function(){
            var c = confirm("Continue delete?");
            if(c)
                jQuery(this).closest('tr').fadeOut(function(){
                    jQuery(this).remove();
                });
            return false;
        });

        // Show aciton upon row hover
        jQuery('.table tbody tr').hover(function(){
            jQuery(this).find('.table-action-hide a').animate({opacity: 1},100);
        },function(){
            jQuery(this).find('.table-action-hide a').animate({opacity: 0},100);
        });

    });
</script>
